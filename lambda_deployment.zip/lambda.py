def test_func_1(event, context):
    print("Test function 1 called successfully!")
    print(f"Event: {event}")

def test_func_2(event, context):
    print("Test function 2 called successfully!")
    print(f"Event: {event}")
